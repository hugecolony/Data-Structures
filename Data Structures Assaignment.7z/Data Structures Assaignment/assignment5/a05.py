class Node:
    def __init__(self,data = None):
        self.val  = data
        self.next = None
class LinkedList:
    def __init__(self):
        self.head = None
def push(self,val):
    new_node =  Node(val)
    #case 1
    if self.head is None:
        self.head  = new_node
        return
    #case2
    last = self.head
    while last.next is not None:
        last = last.next
    last.next = new_node
LinkedList.push = push
def pop(self):
    #case 1 when no node is present
    if self.head is None:
        raise(Exception("NO node is present"))
    #case 2 when only one node is presnet
    if self.head.next is None:
        val = self.head.val
        return val
    #case 3 atleast more than 2 nodes
    temp =  self.head
    while temp.next is not None:
        prev = temp
        temp =  temp.next
    val = temp.val
    prev.next = None
    return val
LinkedList.pop = pop
def insertion(self,index,val):
    new_node = Node(val)
    # insertion at index 0 is different
    if index == 0:
        new_node.next = self.head
        self.head = new_node
        return
    # for other indices
    temp = self.head
    counter = 0
    while temp is not None and counter < index:
        prev = temp
        temp = temp.next
        counter += 1
    prev.next = new_node
    new_node.next = temp
LinkedList.insertion = insertion
def remove(self,val):
    temp  = self.head
    #check if only one node
    if temp is not None:
        if temp.val == val:
            print("Case 1")
            self.head = temp.next
            temp = None
            return
    while temp is not None:
        if temp.val == val:
            break
        prev = temp
        temp = temp.next
    if temp is None:
        print("Case 2.1")
        return
    print("Case 2.2")
    prev.next =  temp.next
LinkedList.remove = remove


def remove_at(self, index):
    if self.head is None:
        raise(IndexError("head is not present"))
    temp = self.head
    #last = self.get_last()

    """
    if last == temp:
        self.head = None
        return
    """
    print("Case 1")
    if index == 0:
        self.head = temp.next
        #self.head = None
        return
    temp = self.head
    counter = 0
    while counter < index:
        prev = temp
        temp = temp.next
        counter += 1
    if temp == self.head:
        self.head = self.head.next
    prev.next = temp.next

LinkedList.remove_at = remove_at
def len(self):
    temp = self.head
    counter = 0
    while temp is not None:
        temp = temp.next
        counter +=1
    return counter
LinkedList.len = len
def __str__(self):
    ret_str = "["
    temp = self.head
    while temp is not None:
        ret_str += str(temp.val) + ","
        temp = temp.next
    ret_str = ret_str.strip(',')
    ret_str += "]"
    return ret_str
LinkedList.__str__ = __str__


def get_last(self):
    if self.head is None:
        return None
    temp = self.head
    while temp.next is not None:
        temp = temp.next
    return temp
LinkedList.get_last = get_last

def reverse_list(self):
    prev = None
    temp = self.head
    while temp is not None:
        pointer = temp.next
        temp.next = prev
        prev = temp
        temp = pointer
    self.head  = prev
LinkedList.reverse_list = reverse_list


if __name__ == '__main__': 
    l = LinkedList() 
    l.push(1)
    l.push(2)
    l.push(3)

    print(l)

    l.reverse_list() 
    print(l)

