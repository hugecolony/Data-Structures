class TreeNode:
    def __init__(self, x):
        self.val = x
        self.left = None
        self.right = None

    # add rest of Tree Node functions here
    def dfs(self):

        print(self.val)

        if self.left:
            self.left.dfs()
        if self.right:
            self.right.dfs()

    def dfs_inorder(self):
        if self.left:
            self.left.dfs_inorder()
        print(self.val)

        if self.right:
            self.right.dfs_inorder()

    def dfs_postorder(self):
        if self.left:
            self.left.dfs_postorder()
        if self.right:
            self.right.dfs_postorder()

        print(self.val)

    def dfs_preorder(self):
        print(self.val)

        if self.left:
            self.left.dfs_preorder()
        if self.right:
            self.right.dfs_preorder()

    def bfs(self):
        to_visit = [self]
        while to_visit:
            current = to_visit.pop(0)

            print(current.val)

            if current.left:
                to_visit.append(current.left)
            if current.right:
                to_visit.append(current.right)


    def dfs_apply(self, fn):
        fn(self)

        if self.left:
            self.left.dfs_apply(fn)
        if self.right:
            self.right.dfs_apply(fn)

class Person:
    def __init__(self, name):
        # super().__init__
        self.name = name

    def __str__(self):
        return str(self.name)


class Collector:
    def __init__(self):
        self.list = []

    def process(self, node):
        self.list.append(str(node.val))

    def get_list(self):
        return self.list

    def reset_list(self):
        self.list = []


# Add the find_val function here ##########
def find_val(self, val):
    if self == None:
        raise (Exception("No node is present"))
    if (str(self.val) == val):
        return self
    if self.left is not None:
        if self.left.find_val(val):
            return (self.left.find_val(val))
        if self.right is not None:
            if self.right.find_val(val):
                return self.right.find_val(val)
    return None
    
# End of find_val function  ################ 
TreeNode.find_val = find_val 


# Add the find_people_in_hierarchy function here ########## 
def find_people_in_hierarchy(self, data):
    c = Collector()
    # print(t_d.find_val(data).val)
    # print(self.val)
    if str(self.val) == data:
        c.reset_list()
        self.dfs_apply(c.process)
        return c.get_list()
    if self.left is not None:
        if str(self.left.val) == data:
            c.reset_list()
            self.left.dfs_apply(c.process)
            return c.get_list()
            if self.left.left:
                if str(self.left.left.find_val(data).val) == data:
                    c.reset_list()
                    self.left.left.dfs_apply(c.process)
                    return c.get_list()
            if self.left.right:
                if str(self.left.right.find_val(data).val) == data:
                    c.reset_list()
                    self.left.right.dfs_apply(c.process)
                    return c.get_list()
        # print("here 1")
        if self.right:
            if str(self.right.val) == data:
                c.reset_list()
                self.right.dfs_apply(c.process)
                return c.get_list()
            if self.right.left:
                if str(self.right.left.val) == data:
                    c.reset_list()
                    self.right.left.dfs_apply(c.process)
                    return c.get_list()
                if self.right.right:
                    if str(self.right.right.val) == data:
                        c.reset_list()
                        self.right.right.dfs_apply(c.process)
                        return c.get_list()
    # print("here 2")
    if self.right is not None:
        if str(self.right.val) == data:
            c.reset_list()
            self.right.dfs_apply(c.process)
            return c.get_list()
            if self.right.left:
                if str(self.right.left.val) == data:
                    c.reset_list()
                    self.right.left.dfs_apply(c.process)
                    return c.get_list()
            if self.right.right:
                if str(self.right.right.val) == data:
                    c.reset_list()
                    self.right.right.dfs_apply(c.process)
                    return c.get_list()

        if self.right:
            if str(self.right.val) == data:
                c.reset_list()
                self.right.dfs_apply(c.process)
                return c.get_list()
            if self.right.left:
                if str(self.right.left.val) == data:
                    c.reset_list()
                    self.right.left.dfs_apply(c.process)
                    return c.get_list()
                if self.right.right:
                    if str(self.right.right.val) == data:
                        c.reset_list()
                        self.right.right.dfs_apply(c.process)
                        return c.get_list()
    raise (ValueError("Expecting a ValueError when node is not found."))


TreeNode.find_people_in_hierarchy = find_people_in_hierarchy
# End of find_people_in_hierarchy function  ################


if __name__ == "__main__":
    # # Section 1: creating people 
    # print("Section 1: ")
     director = Person("Director")
     hod_1 = Person("HoD 1")
     hod_2 = Person("HoD 2")
     faculty_cs_1 = Person("CS 1")
     faculty_cs_2 = Person("CS 2")
     faculty_ee_1 = Person("EE 1")
     faculty_ee_2 = Person("EE 2")
    # print(director) # should print: Director 

    # # Section 2: inserting people in the tree 
    # print("\nSection 2: ")
     t_d = TreeNode(director)
     t_d.left = TreeNode(hod_1)
     t_d.right = TreeNode(hod_2)

     t_d.left.left = TreeNode(faculty_cs_1)
     t_d.left.right = TreeNode(faculty_cs_2)

     t_d.right.left = TreeNode(faculty_ee_1)
     t_d.right.right = TreeNode(faculty_ee_2)
     t_d.dfs()


    # # Section 3: try find_val individually 
    # print("\nSection 3: ")

     node = t_d.find_val("Director")
     print(node.val)  # should print the string: Director


     node = t_d.find_val("HoD 1")
     print(node.val)  # should print the string: HoD 1

     node = t_d.find_val("HoD 2")
     print(node.val)  # should print the string: HoD 2

     node = t_d.find_val("HoD 3")
     print(node)  # should print the string: None


    # # Section 4: try the collector 
    # print("\nSection 4: ")
     c = Collector()
     t_d.dfs_apply(c.process)
     print(c.get_list()) # should print the list: ['Director', 'HoD 1', 'CS 1', 'CS 2', 'HoD 2', 'EE 1', 'EE 2']


    # # Section 5: find hierarchy 
    # print("\nSection 5: ")
     people = t_d.find_people_in_hierarchy("HoD 1")
     print(people)    # Should print the list: ['HoD 1', 'CS 1', 'CS 2']


def search(self, x):
    if self is None:
        return None
    if self.val == x:
        return self.val

    res1 = search(self.left, x)

    """ now recur on right subtree """
    res2 = search(self.right, x)
    if res1 or res2 is None:
        if self.val != x:
            # return x
            raise (Exception(str(x) + " is not present"))
    else:
        return res1 or res2


TreeNode.search = search
