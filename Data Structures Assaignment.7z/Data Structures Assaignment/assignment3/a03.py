class Node:
    def __init__(self,data):
        self.val = data
        self.next = None
class LinkedList:
    def __init__(self):
        self.head = None
def push(self,val):
    new_node = Node(val)
    #CASE 1 when no node is present
    if self.head is None:
        self.head = new_node
        return 
    #Case 2 when more than 1 node is present
    last = self.head
    while last.next is not None:
        last = last.next 
    last.next = new_node
LinkedList.push  = push
def __str__(self):
    ret_str = "["
    temp  = self.head
    while temp is not None:
        ret_str += str(temp.val) +", "
        temp = temp.next
    ret_str = ret_str.rstrip(" ,")
    ret_str += "]"
    return ret_str
LinkedList.__str__ = __str__
def pop(self):
    #case 1 when no node is present 
    if self.head is None:
        raise(Exception("No node is present"))
    #case 2 if noly one node is present
    if self.head.next is None:
        val = self.head.val
        self.head = None
        return val
    #case 3 when more than one node is present
    temp = self.head
    while temp.next  is not None:
        prev = temp 
        temp  = temp.next
    val = temp.val
    prev.next = None
    return(val)
LinkedList.pop = pop
def remove(self,val):
    temp = self.head
    if temp is not None:
        if temp.val ==val:
            self.head = temp.next
            temp = None
            return
    while temp is not None:
        if temp.val == val:
            break
        prev = temp 
        temp = temp.next
    if temp is None:
        return
    prev.next = temp.next
LinkedList.remove  = remove

def len(self):
    temp = self.head
    counter =1
    if temp is None:
        return 0
    while temp.next is not None:
        temp = temp.next 
        counter +=1
    return counter
LinkedList.len = len
def get(self,index):
    if index == 0:
        val = self.head.val
        return val
    temp = self.head
    counter = 0 
    while temp is not None and counter < index:
        temp = temp.next
        counter += 1
    if temp is None:
         raise IndexError("IndexError not raised as expected!")
    val = temp.val
    return val
LinkedList.get = get
if __name__ == "__main__": 
    l = LinkedList() 
    l.push(5) 
    l.push(6) 

    print(l)

    print(l.len())

    l.pop() 
    print(l.len())

    print(l.get(0))
    l.get(2) # Should say "IndexError: Index out of bound"

