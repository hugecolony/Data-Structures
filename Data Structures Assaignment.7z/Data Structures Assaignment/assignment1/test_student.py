from a01 import code_holder 

def test_answer():
    assert code_holder(1, 2) == 3

def test_second():
    assert code_holder(0, 0) == 0 
